# AI-AR Sketch World 🎮🎨

لعبة واقع معزز تفاعلية متقدمة تحول الرسومات اليدوية إلى عوالم ثلاثية الأبعاد حية مع دعم الذكاء الاصطناعي.

## 🌟 الميزات

### ✏️ وضع الرسم (Sketch Mode)
- رسم حر على Canvas
- تحسين الرسومات بـ AI
- معالجة فورية للرسومات
- دعم اللمس والماوس

### 📦 وضع الأصول الجاهزة (Asset Mode)
- اختيار من عناصر جاهزة:
  - 🚂 قطار مع مسار
  - 🚗 سيارة مع حلبة سباق
  - 🦕 ديناصور في عالم ديناصورات
  - 🏠 بيت قابل للدخول
  - 🧱 عناصر LEGO قابلة للتجميع
- وضع الكائنات في العالم بـ AR
- إدارة الأصول الموضوعة

### 🎮 وضع التفاعل (Interaction Mode)
- سحب وإسقاط الكائنات
- دوران الكائنات (Q/E)
- حركة الكائنات (WASD)
- تطبيق قوى فيزيائية
- تحريك الشخصيات والمركبات

### 🤖 تكامل الذكاء الاصطناعي
- معالجة الرسومات بـ ControlNet
- التعرف على الأشياء بـ CLIP
- استخراج خريطة العمق
- توليد عوالم تفاعلية تلقائية

## 📋 المتطلبات

### البرامج المطلوبة
- **Unity 2022.3 LTS** أو أحدث
- **Android SDK** (لـ Android)
- **Xcode** (لـ iOS)
- **Visual Studio** أو **Rider** (محرر الأكواد)

### المكتبات والحزم
```
- AR Foundation
- AR Core (Android)
- AR Kit (iOS)
- Input System
- TextMesh Pro
```

### مفاتيح API
- **Hugging Face API Key** (للذكاء الاصطناعي)

## 🚀 البدء السريع

### 1. فتح المشروع في Unity

```bash
# استنساخ المشروع
git clone https://github.com/yourusername/Unity-AR-SketchWorld.git
cd Unity-AR-SketchWorld

# فتح في Unity
unity -projectPath .
```

### 2. إضافة مفتاح Hugging Face API

1. اذهب إلى `Assets/Scripts/AIIntegrationSystem.cs`
2. استبدل `YOUR_HF_API_KEY` بمفتاحك الفعلي
3. احفظ الملف

### 3. بناء لـ Android

```
File > Build Settings
Select "Android"
Player Settings:
  - Minimum API Level: 24
  - Target API Level: 33
Build > Build APK
```

### 4. بناء لـ iOS

```
File > Build Settings
Select "iOS"
Player Settings:
  - Minimum iOS Version: 14.0
Build > Build
```

## 🎮 التحكم

### لوحة المفاتيح (للاختبار على الكمبيوتر)

| المفتاح | الوظيفة |
|--------|--------|
| `1` | تبديل إلى وضع الرسم |
| `2` | تبديل إلى وضع الأصول |
| `3` | تبديل إلى وضع التفاعل |
| `C` | مسح جميع الكائنات |
| `W/A/S/D` | تحريك الكائن |
| `Q/E` | دوران الكائن |
| `Mouse Drag` | سحب الكائن |

### اللمس (على الهاتف)

| الحركة | الوظيفة |
|--------|--------|
| اللمس والرسم | رسم على Canvas |
| النقر على الكائن | اختيار الكائن |
| السحب | تحريك الكائن |
| الإفلات | وضع الكائن |

## 📁 هيكل المشروع

```
Unity-AR-SketchWorld/
├── Assets/
│   ├── Scripts/
│   │   ├── GameManager.cs              # مدير اللعبة الرئيسي
│   │   ├── SketchSystem.cs             # نظام الرسم
│   │   ├── AssetSystem.cs              # نظام الأصول
│   │   ├── InteractionSystem.cs        # نظام التفاعل
│   │   └── AIIntegrationSystem.cs      # نظام الذكاء الاصطناعي
│   ├── Prefabs/                        # النماذج الأولية
│   ├── Models/                         # النماذج ثلاثية الأبعاد
│   ├── Materials/                      # المواد والملمسات
│   ├── Scenes/                         # المشاهد
│   └── UI/                             # عناصر الواجهة
├── ProjectSettings.json                # إعدادات المشروع
└── README.md                           # هذا الملف
```

## 🔧 التطوير

### إضافة أصل جديد

```csharp
// في GameManager أو AssetSystem
Asset newAsset = new Asset
{
    name = "My Object",
    prefab = myPrefab,
    icon = myIcon,
    description = "Description"
};

assetSystem.AddAsset(newAsset);
```

### إضافة حركة مخصصة

```csharp
// إنشاء مكون حركة جديد
public class MyMovement : MonoBehaviour
{
    public float speed = 5f;
    
    private void Update()
    {
        transform.Translate(Vector3.forward * speed * Time.deltaTime);
    }
}
```

### تكامل نموذج AI جديد

```csharp
// في AIIntegrationSystem
private IEnumerator AnalyzeWithCustomModel(byte[] data)
{
    using (UnityWebRequest request = new UnityWebRequest(
        HF_API_URL + "your-model-name",
        "POST"
    ))
    {
        // معالجة الطلب
        yield return request.SendWebRequest();
    }
}
```

## 🧪 الاختبار

### اختبار على محاكي Android

```bash
# تثبيت APK على المحاكي
adb install -r Build/app-debug.apk

# تشغيل التطبيق
adb shell am start -n com.yourcompany.arsketchworld/.MainActivity
```

### اختبار على محاكي iOS

```bash
# بناء المشروع في Xcode
open Build/iOS/Unity-iPhone.xcodeproj

# تشغيل على المحاكي
xcodebuild -scheme Unity-iPhone -configuration Debug -derivedDataPath build -arch x86_64 -sdk iphonesimulator
```

## 📚 الموارد

- [Unity AR Foundation Documentation](https://docs.unity3d.com/Packages/com.unity.xr.arfoundation@latest)
- [Hugging Face API Documentation](https://huggingface.co/docs/api-inference)
- [AR Core Documentation](https://developers.google.com/ar/develop)
- [AR Kit Documentation](https://developer.apple.com/arkit/)

## 🐛 استكشاف الأخطاء

### المشكلة: لا تظهر الكاميرا AR
**الحل:**
- تأكد من تفعيل الأذونات في `AndroidManifest.xml`
- تحقق من أن الجهاز يدعم AR
- أعد تشغيل التطبيق

### المشكلة: لا تعمل معالجة AI
**الحل:**
- تحقق من مفتاح Hugging Face API
- تأكد من اتصال الإنترنت
- تحقق من استجابة API في وحدة التحكم

### المشكلة: الكائنات تسقط من العالم
**الحل:**
- تأكد من وجود Collider على الأرضية
- تحقق من إعدادات الفيزياء
- أضف Rigidbody مع `Use Gravity = true`

## 📝 الترخيص

هذا المشروع مرخص تحت MIT License - انظر ملف LICENSE للتفاصيل.

## 👥 المساهمة

نرحب بالمساهمات! يرجى:

1. Fork المشروع
2. إنشاء فرع للميزة الجديدة (`git checkout -b feature/AmazingFeature`)
3. Commit التغييرات (`git commit -m 'Add some AmazingFeature'`)
4. Push إلى الفرع (`git push origin feature/AmazingFeature`)
5. فتح Pull Request

## 📞 الدعم

للمساعدة والدعم:
- 📧 البريد الإلكتروني: support@arsketchworld.com
- 💬 Discord: [رابط السيرفر]
- 🐛 Issues: [GitHub Issues]

## 🎯 الخطط المستقبلية

- [ ] دعم الألعاب متعددة اللاعبين
- [ ] نماذج AI أكثر تقدماً
- [ ] مشاركة العوالم الاجتماعية
- [ ] محرر مشاهد متقدم
- [ ] دعم الأصوات والموسيقى
- [ ] نظام الإنجازات والمكافآت

---

**آخر تحديث:** أبريل 2026
**الإصدار:** 1.0.0
