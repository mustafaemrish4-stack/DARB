using UnityEngine;
using UnityEngine.XR.ARFoundation;
using System.Collections.Generic;

/// <summary>
/// AssetSystem - نظام الأصول الجاهزة
/// يدير اختيار ووضع الكائنات الجاهزة (قطار، سيارة، ديناصور، إلخ)
/// </summary>
public class AssetSystem : MonoBehaviour
{
    [System.Serializable]
    public class Asset
    {
        public string name;
        public GameObject prefab;
        public Sprite icon;
        public string description;
    }

    [SerializeField] private List<Asset> availableAssets = new List<Asset>();
    [SerializeField] private ARRaycastManager raycastManager;
    [SerializeField] private Transform assetContainer;

    private Asset selectedAsset;
    private List<GameObject> placedAssets = new List<GameObject>();
    private static List<ARRaycastHit> hits = new List<ARRaycastHit>();

    private void OnEnable()
    {
        InitializeAssets();
    }

    /// <summary>
    /// تهيئة الأصول
    /// </summary>
    private void InitializeAssets()
    {
        if (raycastManager == null)
            raycastManager = FindObjectOfType<ARRaycastManager>();

        if (assetContainer == null)
            assetContainer = new GameObject("AssetContainer").transform;

        // إنشاء الأصول الافتراضية إذا لم تكن موجودة
        if (availableAssets.Count == 0)
        {
            CreateDefaultAssets();
        }

        Debug.Log($"Asset System initialized with {availableAssets.Count} assets");
    }

    /// <summary>
    /// إنشاء أصول افتراضية
    /// </summary>
    private void CreateDefaultAssets()
    {
        // سيتم إضافة الأصول من خلال المحرر
        Debug.Log("Please add assets through the Inspector");
    }

    /// <summary>
    /// اختيار أصل
    /// </summary>
    public void SelectAsset(int index)
    {
        if (index >= 0 && index < availableAssets.Count)
        {
            selectedAsset = availableAssets[index];
            Debug.Log($"Selected asset: {selectedAsset.name}");
        }
    }

    /// <summary>
    /// اختيار أصل بالاسم
    /// </summary>
    public void SelectAssetByName(string assetName)
    {
        foreach (Asset asset in availableAssets)
        {
            if (asset.name == assetName)
            {
                selectedAsset = asset;
                Debug.Log($"Selected asset: {assetName}");
                return;
            }
        }
        Debug.LogWarning($"Asset not found: {assetName}");
    }

    private void Update()
    {
        if (!enabled || selectedAsset == null) return;

        HandleAssetPlacement();
    }

    /// <summary>
    /// معالجة وضع الأصول
    /// </summary>
    private void HandleAssetPlacement()
    {
        // اكتشاف اللمس
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            if (touch.phase == TouchPhase.Began)
            {
                PlaceAssetAtTouchPosition(touch.position);
            }
        }

        // دعم الماوس للاختبار
        if (Input.GetMouseButtonDown(0))
        {
            PlaceAssetAtTouchPosition(Input.mousePosition);
        }
    }

    /// <summary>
    /// وضع أصل في موقع اللمس
    /// </summary>
    private void PlaceAssetAtTouchPosition(Vector2 touchPosition)
    {
        if (raycastManager.Raycast(touchPosition, hits, UnityEngine.XR.ARSubsystems.TrackableType.PlaneWithinPolygon))
        {
            Pose hitPose = hits[0].pose;
            PlaceAsset(hitPose.position, hitPose.rotation);
        }
    }

    /// <summary>
    /// وضع أصل في موقع معين
    /// </summary>
    public void PlaceAsset(Vector3 position, Quaternion rotation)
    {
        if (selectedAsset == null || selectedAsset.prefab == null)
        {
            Debug.LogWarning("No asset selected or prefab is null");
            return;
        }

        GameObject instance = Instantiate(
            selectedAsset.prefab,
            position,
            rotation,
            assetContainer
        );

        // إضافة مكونات التفاعل
        AddInteractionComponents(instance);

        placedAssets.Add(instance);
        Debug.Log($"Asset placed: {selectedAsset.name} at {position}");
    }

    /// <summary>
    /// إضافة مكونات التفاعل
    /// </summary>
    private void AddInteractionComponents(GameObject obj)
    {
        // إضافة Rigidbody
        if (obj.GetComponent<Rigidbody>() == null)
        {
            Rigidbody rb = obj.AddComponent<Rigidbody>();
            rb.useGravity = true;
            rb.mass = 1f;
        }

        // إضافة Collider
        if (obj.GetComponent<Collider>() == null)
        {
            obj.AddComponent<BoxCollider>();
        }

        // إضافة مكون التفاعل
        if (obj.GetComponent<InteractableObject>() == null)
        {
            obj.AddComponent<InteractableObject>();
        }
    }

    /// <summary>
    /// الحصول على قائمة الأصول المتاحة
    /// </summary>
    public List<Asset> GetAvailableAssets()
    {
        return availableAssets;
    }

    /// <summary>
    /// الحصول على الأصل المختار
    /// </summary>
    public Asset GetSelectedAsset()
    {
        return selectedAsset;
    }

    /// <summary>
    /// الحصول على قائمة الأصول الموضوعة
    /// </summary>
    public List<GameObject> GetPlacedAssets()
    {
        return placedAssets;
    }

    /// <summary>
    /// حذف أصل موضوع
    /// </summary>
    public void RemoveAsset(GameObject asset)
    {
        if (placedAssets.Contains(asset))
        {
            placedAssets.Remove(asset);
            Destroy(asset);
            Debug.Log("Asset removed");
        }
    }

    /// <summary>
    /// مسح جميع الأصول الموضوعة
    /// </summary>
    public void ClearAllAssets()
    {
        foreach (GameObject asset in placedAssets)
        {
            Destroy(asset);
        }
        placedAssets.Clear();
        Debug.Log("All assets cleared");
    }

    /// <summary>
    /// إضافة أصل جديد
    /// </summary>
    public void AddAsset(Asset asset)
    {
        availableAssets.Add(asset);
        Debug.Log($"Asset added: {asset.name}");
    }
}

/// <summary>
/// مكون الكائن التفاعلي
/// </summary>
public class InteractableObject : MonoBehaviour
{
    private Rigidbody rb;
    private bool isSelected = false;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    private void OnMouseDown()
    {
        isSelected = true;
        if (rb)
            rb.isKinematic = true;
    }

    private void OnMouseDrag()
    {
        if (isSelected && rb)
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            rb.velocity = ray.direction * 5f;
        }
    }

    private void OnMouseUp()
    {
        isSelected = false;
        if (rb)
            rb.isKinematic = false;
    }

    /// <summary>
    /// تطبيق قوة على الكائن
    /// </summary>
    public void ApplyForce(Vector3 force)
    {
        if (rb)
            rb.AddForce(force, ForceMode.Impulse);
    }

    /// <summary>
    /// تدوير الكائن
    /// </summary>
    public void Rotate(Vector3 axis, float angle)
    {
        transform.Rotate(axis, angle);
    }
}
