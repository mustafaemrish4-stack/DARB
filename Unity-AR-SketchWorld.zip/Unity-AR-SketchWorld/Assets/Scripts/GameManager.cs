using UnityEngine;
using UnityEngine.XR.ARFoundation;
using System.Collections.Generic;

/// <summary>
/// GameManager - مدير اللعبة الرئيسي
/// يدير جميع أوضاع اللعبة والتفاعلات
/// </summary>
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [System.Serializable]
    public enum GameMode
    {
        SketchMode,      // وضع الرسم
        AssetMode,       // وضع الأصول الجاهزة
        InteractionMode  // وضع التفاعل
    }

    [SerializeField] private GameMode currentMode = GameMode.SketchMode;
    [SerializeField] private ARSession arSession;
    [SerializeField] private ARRaycastManager raycastManager;
    [SerializeField] private ARPlaneManager planeManager;

    private SketchSystem sketchSystem;
    private AssetSystem assetSystem;
    private InteractionSystem interactionSystem;
    private AIIntegrationSystem aiSystem;

    private List<GameObject> placedObjects = new List<GameObject>();

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void Start()
    {
        InitializeARSession();
        InitializeSystems();
        SetGameMode(GameMode.SketchMode);
    }

    /// <summary>
    /// تهيئة جلسة AR
    /// </summary>
    private void InitializeARSession()
    {
        if (arSession == null)
            arSession = GetComponent<ARSession>();

        if (raycastManager == null)
            raycastManager = GetComponent<ARRaycastManager>();

        if (planeManager == null)
            planeManager = GetComponent<ARPlaneManager>();

        Debug.Log("AR Session initialized successfully");
    }

    /// <summary>
    /// تهيئة جميع الأنظمة
    /// </summary>
    private void InitializeSystems()
    {
        sketchSystem = GetComponent<SketchSystem>();
        assetSystem = GetComponent<AssetSystem>();
        interactionSystem = GetComponent<InteractionSystem>();
        aiSystem = GetComponent<AIIntegrationSystem>();

        if (sketchSystem == null)
            sketchSystem = gameObject.AddComponent<SketchSystem>();

        if (assetSystem == null)
            assetSystem = gameObject.AddComponent<AssetSystem>();

        if (interactionSystem == null)
            interactionSystem = gameObject.AddComponent<InteractionSystem>();

        if (aiSystem == null)
            aiSystem = gameObject.AddComponent<AIIntegrationSystem>();

        Debug.Log("All systems initialized");
    }

    /// <summary>
    /// تعيين وضع اللعبة
    /// </summary>
    public void SetGameMode(GameMode mode)
    {
        currentMode = mode;

        // تعطيل جميع الأنظمة
        if (sketchSystem) sketchSystem.enabled = false;
        if (assetSystem) assetSystem.enabled = false;
        if (interactionSystem) interactionSystem.enabled = false;

        // تفعيل النظام المطلوب
        switch (mode)
        {
            case GameMode.SketchMode:
                if (sketchSystem) sketchSystem.enabled = true;
                Debug.Log("Switched to Sketch Mode");
                break;

            case GameMode.AssetMode:
                if (assetSystem) assetSystem.enabled = true;
                Debug.Log("Switched to Asset Mode");
                break;

            case GameMode.InteractionMode:
                if (interactionSystem) interactionSystem.enabled = true;
                Debug.Log("Switched to Interaction Mode");
                break;
        }
    }

    /// <summary>
    /// الحصول على الوضع الحالي
    /// </summary>
    public GameMode GetCurrentMode()
    {
        return currentMode;
    }

    /// <summary>
    /// وضع كائن في العالم
    /// </summary>
    public void PlaceObject(GameObject prefab, Vector3 position, Quaternion rotation)
    {
        GameObject instance = Instantiate(prefab, position, rotation);
        placedObjects.Add(instance);
        Debug.Log($"Object placed: {prefab.name}");
    }

    /// <summary>
    /// الحصول على قائمة الكائنات الموضوعة
    /// </summary>
    public List<GameObject> GetPlacedObjects()
    {
        return placedObjects;
    }

    /// <summary>
    /// حذف كائن من العالم
    /// </summary>
    public void RemoveObject(GameObject obj)
    {
        if (placedObjects.Contains(obj))
        {
            placedObjects.Remove(obj);
            Destroy(obj);
            Debug.Log("Object removed");
        }
    }

    /// <summary>
    /// مسح جميع الكائنات
    /// </summary>
    public void ClearAllObjects()
    {
        foreach (GameObject obj in placedObjects)
        {
            Destroy(obj);
        }
        placedObjects.Clear();
        Debug.Log("All objects cleared");
    }

    private void Update()
    {
        HandleInput();
    }

    /// <summary>
    /// معالجة الإدخال
    /// </summary>
    private void HandleInput()
    {
        // تبديل الأوضاع بالأرقام
        if (Input.GetKeyDown(KeyCode.Alpha1))
            SetGameMode(GameMode.SketchMode);

        if (Input.GetKeyDown(KeyCode.Alpha2))
            SetGameMode(GameMode.AssetMode);

        if (Input.GetKeyDown(KeyCode.Alpha3))
            SetGameMode(GameMode.InteractionMode);

        // مسح جميع الكائنات بـ C
        if (Input.GetKeyDown(KeyCode.C))
            ClearAllObjects();
    }
}
