using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// InteractionSystem - نظام التفاعل والفيزياء
/// يدير تفاعل المستخدم مع الكائنات والشخصيات
/// </summary>
public class InteractionSystem : MonoBehaviour
{
    [SerializeField] private float dragForce = 10f;
    [SerializeField] private float rotationSpeed = 100f;
    [SerializeField] private float moveSpeed = 5f;

    private GameObject selectedObject;
    private Vector3 dragOffset;
    private Camera mainCamera;
    private List<GameObject> interactableObjects = new List<GameObject>();

    private void OnEnable()
    {
        mainCamera = Camera.main;
        FindInteractableObjects();
    }

    /// <summary>
    /// البحث عن الكائنات التفاعلية
    /// </summary>
    private void FindInteractableObjects()
    {
        InteractableObject[] objects = FindObjectsOfType<InteractableObject>();
        foreach (InteractableObject obj in objects)
        {
            interactableObjects.Add(obj.gameObject);
        }
    }

    private void Update()
    {
        if (!enabled) return;

        HandleInteraction();
        HandleMovement();
        HandleRotation();
    }

    /// <summary>
    /// معالجة التفاعل مع الكائنات
    /// </summary>
    private void HandleInteraction()
    {
        // اكتشاف اللمس
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            if (touch.phase == TouchPhase.Began)
            {
                SelectObjectAtPosition(touch.position);
            }
            else if (touch.phase == TouchPhase.Moved && selectedObject != null)
            {
                DragObject(touch.position);
            }
            else if (touch.phase == TouchPhase.Ended)
            {
                ReleaseObject();
            }
        }

        // دعم الماوس للاختبار
        if (Input.GetMouseButtonDown(0))
        {
            SelectObjectAtPosition(Input.mousePosition);
        }

        if (Input.GetMouseButton(0) && selectedObject != null)
        {
            DragObject(Input.mousePosition);
        }

        if (Input.GetMouseButtonUp(0))
        {
            ReleaseObject();
        }
    }

    /// <summary>
    /// اختيار كائن في موقع معين
    /// </summary>
    private void SelectObjectAtPosition(Vector2 screenPosition)
    {
        Ray ray = mainCamera.ScreenPointToRay(screenPosition);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit))
        {
            InteractableObject interactable = hit.collider.GetComponent<InteractableObject>();
            if (interactable != null)
            {
                selectedObject = interactable.gameObject;
                dragOffset = selectedObject.transform.position - hit.point;
                Debug.Log($"Selected object: {selectedObject.name}");
            }
        }
    }

    /// <summary>
    /// سحب الكائن
    /// </summary>
    private void DragObject(Vector2 screenPosition)
    {
        if (selectedObject == null) return;

        Ray ray = mainCamera.ScreenPointToRay(screenPosition);
        Vector3 targetPosition = ray.origin + ray.direction * 5f + dragOffset;

        Rigidbody rb = selectedObject.GetComponent<Rigidbody>();
        if (rb)
        {
            rb.velocity = (targetPosition - selectedObject.transform.position) * dragForce;
        }
        else
        {
            selectedObject.transform.position = targetPosition;
        }
    }

    /// <summary>
    /// تحرير الكائن
    /// </summary>
    private void ReleaseObject()
    {
        if (selectedObject != null)
        {
            Rigidbody rb = selectedObject.GetComponent<Rigidbody>();
            if (rb)
            {
                rb.velocity = Vector3.zero;
            }
            selectedObject = null;
        }
    }

    /// <summary>
    /// معالجة حركة الكائنات
    /// </summary>
    private void HandleMovement()
    {
        if (selectedObject == null) return;

        // حركة بالأسهم
        Vector3 movement = Vector3.zero;

        if (Input.GetKey(KeyCode.W))
            movement += Vector3.forward;
        if (Input.GetKey(KeyCode.S))
            movement += Vector3.back;
        if (Input.GetKey(KeyCode.A))
            movement += Vector3.left;
        if (Input.GetKey(KeyCode.D))
            movement += Vector3.right;

        if (movement != Vector3.zero)
        {
            Rigidbody rb = selectedObject.GetComponent<Rigidbody>();
            if (rb)
            {
                rb.velocity = movement.normalized * moveSpeed;
            }
            else
            {
                selectedObject.transform.Translate(movement.normalized * moveSpeed * Time.deltaTime);
            }
        }
    }

    /// <summary>
    /// معالجة دوران الكائنات
    /// </summary>
    private void HandleRotation()
    {
        if (selectedObject == null) return;

        // دوران بـ Q و E
        if (Input.GetKey(KeyCode.Q))
        {
            selectedObject.transform.Rotate(Vector3.up, -rotationSpeed * Time.deltaTime);
        }

        if (Input.GetKey(KeyCode.E))
        {
            selectedObject.transform.Rotate(Vector3.up, rotationSpeed * Time.deltaTime);
        }
    }

    /// <summary>
    /// تطبيق قوة على كائن
    /// </summary>
    public void ApplyForceToObject(GameObject obj, Vector3 force)
    {
        Rigidbody rb = obj.GetComponent<Rigidbody>();
        if (rb)
        {
            rb.AddForce(force, ForceMode.Impulse);
        }
    }

    /// <summary>
    /// تدوير كائن
    /// </summary>
    public void RotateObject(GameObject obj, Vector3 axis, float angle)
    {
        obj.transform.Rotate(axis, angle);
    }

    /// <summary>
    /// تحريك كائن إلى موقع
    /// </summary>
    public void MoveObjectToPosition(GameObject obj, Vector3 targetPosition, float duration)
    {
        StartCoroutine(MoveCoroutine(obj, targetPosition, duration));
    }

    /// <summary>
    /// Coroutine لتحريك الكائن
    /// </summary>
    private System.Collections.IEnumerator MoveCoroutine(GameObject obj, Vector3 targetPosition, float duration)
    {
        Vector3 startPosition = obj.transform.position;
        float elapsedTime = 0f;

        while (elapsedTime < duration)
        {
            elapsedTime += Time.deltaTime;
            float t = elapsedTime / duration;
            obj.transform.position = Vector3.Lerp(startPosition, targetPosition, t);
            yield return null;
        }

        obj.transform.position = targetPosition;
    }

    /// <summary>
    /// الحصول على الكائن المختار
    /// </summary>
    public GameObject GetSelectedObject()
    {
        return selectedObject;
    }

    /// <summary>
    /// الحصول على قائمة الكائنات التفاعلية
    /// </summary>
    public List<GameObject> GetInteractableObjects()
    {
        return interactableObjects;
    }

    /// <summary>
    /// إضافة كائن تفاعلي
    /// </summary>
    public void AddInteractableObject(GameObject obj)
    {
        if (!interactableObjects.Contains(obj))
        {
            interactableObjects.Add(obj);
        }
    }

    /// <summary>
    /// إزالة كائن تفاعلي
    /// </summary>
    public void RemoveInteractableObject(GameObject obj)
    {
        interactableObjects.Remove(obj);
    }
}

/// <summary>
/// نظام الحركة للشخصيات والمركبات
/// </summary>
public class CharacterController : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float rotationSpeed = 100f;
    [SerializeField] private Animator animator;

    private Rigidbody rb;
    private Vector3 moveDirection;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        if (animator == null)
            animator = GetComponent<Animator>();
    }

    /// <summary>
    /// تحريك الشخصية
    /// </summary>
    public void Move(Vector3 direction)
    {
        moveDirection = direction.normalized;

        if (rb)
        {
            rb.velocity = moveDirection * moveSpeed;
        }
        else
        {
            transform.Translate(moveDirection * moveSpeed * Time.deltaTime);
        }

        // تحديث الرسوم المتحركة
        if (animator)
        {
            animator.SetFloat("Speed", moveDirection.magnitude);
        }

        // توجيه الشخصية نحو اتجاه الحركة
        if (moveDirection.magnitude > 0)
        {
            Quaternion targetRotation = Quaternion.LookRotation(moveDirection);
            transform.rotation = Quaternion.Lerp(
                transform.rotation,
                targetRotation,
                rotationSpeed * Time.deltaTime
            );
        }
    }

    /// <summary>
    /// إيقاف الشخصية
    /// </summary>
    public void Stop()
    {
        moveDirection = Vector3.zero;

        if (rb)
        {
            rb.velocity = Vector3.zero;
        }

        if (animator)
        {
            animator.SetFloat("Speed", 0);
        }
    }

    /// <summary>
    /// تشغيل رسم متحرك
    /// </summary>
    public void PlayAnimation(string animationName)
    {
        if (animator)
        {
            animator.SetTrigger(animationName);
        }
    }
}
