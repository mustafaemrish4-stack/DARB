using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

/// <summary>
/// SketchSystem - نظام الرسم التفاعلي
/// يتعامل مع رسم المسارات والأشكال على Canvas
/// </summary>
public class SketchSystem : MonoBehaviour
{
    [SerializeField] private Canvas sketchCanvas;
    [SerializeField] private RawImage drawingImage;
    [SerializeField] private Button clearButton;
    [SerializeField] private Button submitButton;
    [SerializeField] private Button improveButton;

    private Texture2D drawingTexture;
    private Color[] clearPixels;
    private Vector2 previousMousePosition;
    private bool isDrawing = false;

    [SerializeField] private int textureWidth = 512;
    [SerializeField] private int textureHeight = 512;
    [SerializeField] private float brushSize = 5f;
    [SerializeField] private Color brushColor = Color.white;

    private List<Vector2> currentStroke = new List<Vector2>();
    private AIIntegrationSystem aiSystem;

    private void OnEnable()
    {
        InitializeSketchSystem();
    }

    private void OnDisable()
    {
        if (sketchCanvas)
            sketchCanvas.gameObject.SetActive(false);
    }

    /// <summary>
    /// تهيئة نظام الرسم
    /// </summary>
    private void InitializeSketchSystem()
    {
        // إنشاء نسيج الرسم
        drawingTexture = new Texture2D(textureWidth, textureHeight, TextureFormat.RGBA32, false);
        clearPixels = new Color[textureWidth * textureHeight];

        // ملء بألوان شفافة
        for (int i = 0; i < clearPixels.Length; i++)
        {
            clearPixels[i] = Color.clear;
        }

        drawingTexture.SetPixels(clearPixels);
        drawingTexture.Apply();

        if (drawingImage)
            drawingImage.texture = drawingTexture;

        // ربط الأزرار
        if (clearButton)
            clearButton.onClick.AddListener(ClearDrawing);

        if (submitButton)
            submitButton.onClick.AddListener(SubmitSketch);

        if (improveButton)
            improveButton.onClick.AddListener(ImproveDrawing);

        aiSystem = GameManager.Instance.GetComponent<AIIntegrationSystem>();

        if (sketchCanvas)
            sketchCanvas.gameObject.SetActive(true);

        Debug.Log("Sketch System initialized");
    }

    private void Update()
    {
        if (!enabled) return;

        HandleDrawing();
    }

    /// <summary>
    /// معالجة الرسم
    /// </summary>
    private void HandleDrawing()
    {
        // اكتشاف اللمس على الهاتف
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            if (touch.phase == TouchPhase.Began)
            {
                StartDrawing(touch.position);
            }
            else if (touch.phase == TouchPhase.Moved)
            {
                DrawLine(touch.position);
            }
            else if (touch.phase == TouchPhase.Ended)
            {
                EndDrawing();
            }
        }

        // دعم الماوس للاختبار
        if (Input.GetMouseButtonDown(0))
        {
            StartDrawing(Input.mousePosition);
        }

        if (Input.GetMouseButton(0))
        {
            DrawLine(Input.mousePosition);
        }

        if (Input.GetMouseButtonUp(0))
        {
            EndDrawing();
        }
    }

    /// <summary>
    /// بدء الرسم
    /// </summary>
    private void StartDrawing(Vector2 position)
    {
        isDrawing = true;
        previousMousePosition = position;
        currentStroke.Clear();
        currentStroke.Add(position);
    }

    /// <summary>
    /// رسم خط
    /// </summary>
    private void DrawLine(Vector2 currentMousePosition)
    {
        if (!isDrawing) return;

        currentStroke.Add(currentMousePosition);

        // تحويل إحداثيات الشاشة إلى إحداثيات النسيج
        Vector2 textureCoord = GetTextureCoordinate(currentMousePosition);

        // رسم خط من النقطة السابقة إلى الحالية
        DrawLineOnTexture(
            GetTextureCoordinate(previousMousePosition),
            textureCoord,
            brushColor,
            brushSize
        );

        drawingTexture.Apply();
        previousMousePosition = currentMousePosition;
    }

    /// <summary>
    /// إنهاء الرسم
    /// </summary>
    private void EndDrawing()
    {
        isDrawing = false;
    }

    /// <summary>
    /// رسم خط على النسيج
    /// </summary>
    private void DrawLineOnTexture(Vector2 from, Vector2 to, Color color, float width)
    {
        Vector2 direction = (to - from).normalized;
        float distance = Vector2.Distance(from, to);

        for (float i = 0; i < distance; i += 1f)
        {
            Vector2 point = from + direction * i;
            DrawBrushStroke(point, color, width);
        }
    }

    /// <summary>
    /// رسم ضربة فرشاة
    /// </summary>
    private void DrawBrushStroke(Vector2 center, Color color, float width)
    {
        int centerX = (int)center.x;
        int centerY = (int)center.y;
        int radius = (int)(width / 2);

        for (int x = centerX - radius; x < centerX + radius; x++)
        {
            for (int y = centerY - radius; y < centerY + radius; y++)
            {
                if (x >= 0 && x < textureWidth && y >= 0 && y < textureHeight)
                {
                    float dist = Vector2.Distance(new Vector2(x, y), center);
                    if (dist <= radius)
                    {
                        drawingTexture.SetPixel(x, y, color);
                    }
                }
            }
        }
    }

    /// <summary>
    /// تحويل إحداثيات الشاشة إلى إحداثيات النسيج
    /// </summary>
    private Vector2 GetTextureCoordinate(Vector2 screenPosition)
    {
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            drawingImage.rectTransform,
            screenPosition,
            null,
            out Vector2 localPoint
        );

        Rect rect = drawingImage.rectTransform.rect;
        float x = (localPoint.x - rect.x) / rect.width * textureWidth;
        float y = (localPoint.y - rect.y) / rect.height * textureHeight;

        return new Vector2(Mathf.Clamp(x, 0, textureWidth - 1), Mathf.Clamp(y, 0, textureHeight - 1));
    }

    /// <summary>
    /// مسح الرسم
    /// </summary>
    private void ClearDrawing()
    {
        drawingTexture.SetPixels(clearPixels);
        drawingTexture.Apply();
        currentStroke.Clear();
        Debug.Log("Drawing cleared");
    }

    /// <summary>
    /// تحسين الرسم باستخدام AI
    /// </summary>
    private void ImproveDrawing()
    {
        if (aiSystem)
        {
            Debug.Log("Improving drawing with AI...");
            // سيتم تنفيذه في نظام AI
        }
    }

    /// <summary>
    /// إرسال الرسم للمعالجة
    /// </summary>
    private void SubmitSketch()
    {
        // تحويل النسيج إلى Texture2D
        byte[] pngData = drawingTexture.EncodeToPNG();

        if (aiSystem)
        {
            Debug.Log("Submitting sketch for processing...");
            aiSystem.ProcessSketch(pngData);
        }

        ClearDrawing();
    }

    /// <summary>
    /// الحصول على نسيج الرسم الحالي
    /// </summary>
    public Texture2D GetDrawingTexture()
    {
        return drawingTexture;
    }

    /// <summary>
    /// الحصول على بيانات الرسم
    /// </summary>
    public byte[] GetDrawingData()
    {
        return drawingTexture.EncodeToPNG();
    }
}
