# دليل الإعداد الكامل - AI-AR Sketch World

## 📋 المرحلة الأولى: التثبيت الأساسي

### 1. تثبيت Unity

#### على Windows
```bash
# تحميل Unity Hub
https://unity.com/download

# تثبيت Unity 2022.3 LTS
unity-hub://download/2022.3.0f1/windows
```

#### على Mac
```bash
# تحميل Unity Hub
https://unity.com/download

# تثبيت Unity 2022.3 LTS
unity-hub://download/2022.3.0f1/mac
```

#### على Linux
```bash
# تحميل Unity Hub
https://unity.com/download

# تثبيت Unity 2022.3 LTS
unity-hub://download/2022.3.0f1/linux
```

### 2. تثبيت Android SDK (لـ Android)

#### على Windows
```bash
# تحميل Android Studio
https://developer.android.com/studio

# تثبيت SDK
- فتح Android Studio
- Tools > SDK Manager
- تثبيت Android 13 (API 33)
- تثبيت Android 7 (API 24) - الحد الأدنى
```

#### على Mac
```bash
# تثبيت عبر Homebrew
brew install android-sdk
brew install android-ndk

# أو تحميل Android Studio مباشرة
https://developer.android.com/studio
```

### 3. تثبيت Xcode (لـ iOS)

```bash
# على Mac فقط
xcode-select --install

# أو من App Store
https://apps.apple.com/app/xcode/id497799835
```

### 4. استنساخ المشروع

```bash
# استنساخ المشروع
git clone https://github.com/yourusername/Unity-AR-SketchWorld.git
cd Unity-AR-SketchWorld

# أو تحميل ZIP
# https://github.com/yourusername/Unity-AR-SketchWorld/archive/refs/heads/main.zip
```

---

## 🔑 المرحلة الثانية: إعداد مفاتيح API

### 1. الحصول على مفتاح Hugging Face API

```bash
# 1. اذهب إلى https://huggingface.co
# 2. سجل حسابك أو سجل الدخول
# 3. اذهب إلى Settings > Access Tokens
# 4. انقر على "New token"
# 5. اختر "Read" كنوع الوصول
# 6. انسخ المفتاح
```

### 2. إضافة المفتاح إلى المشروع

```csharp
// في Assets/Scripts/AIIntegrationSystem.cs
[SerializeField] private string huggingFaceAPIKey = "hf_YOUR_API_KEY_HERE";
```

### 3. (اختياري) إضافة مفاتيح إضافية

```csharp
// للخدمات الإضافية
[SerializeField] private string meshyAIKey = "YOUR_MESHY_KEY";
[SerializeField] private string sketchfabKey = "YOUR_SKETCHFAB_KEY";
```

---

## 🎮 المرحلة الثالثة: فتح المشروع في Unity

### 1. فتح Unity Hub

```bash
# تشغيل Unity Hub
unity-hub://
```

### 2. إضافة المشروع

```
1. انقر على "Add"
2. اختر مجلد Unity-AR-SketchWorld
3. انقر على "Open"
```

### 3. انتظار استيراد الأصول

- سيستغرق 5-10 دقائق
- تجاهل أي تحذيرات حول الإصدارات

### 4. فتح المشهد الرئيسي

```
Assets > Scenes > MainScene.unity
```

---

## 📱 المرحلة الرابعة: إعداد البناء

### إعداد Android

#### الخطوة 1: إعدادات اللاعب

```
Edit > Project Settings > Player
```

#### الخطوة 2: إعدادات Android

```
Platform: Android

Resolution and Presentation:
  - Default Orientation: Portrait
  - Supported Aspect Ratios: 9:16

Other Settings:
  - Minimum API Level: 24 (Android 7.0)
  - Target API Level: 33 (Android 13)
  - Graphics APIs: OpenGL ES 3.0
  - Scripting Backend: IL2CPP
  - ARM64: Enabled
```

#### الخطوة 3: إعدادات XR

```
XR Plug-in Management:
  - Enable ARCore
  - ARCore XR Plugin Settings:
    - Enable ARCore: True
    - Depth: Enabled
    - Geospatial: Optional
```

#### الخطوة 4: الأذونات

```
في AndroidManifest.xml أضف:

<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
```

### إعداد iOS

#### الخطوة 1: إعدادات اللاعب

```
Edit > Project Settings > Player
```

#### الخطوة 2: إعدادات iOS

```
Platform: iOS

Resolution and Presentation:
  - Default Orientation: Portrait
  - Supported Orientations: Portrait

Other Settings:
  - Minimum iOS Version: 14.0
  - Scripting Backend: IL2CPP
  - Architecture: ARM64
```

#### الخطوة 3: إعدادات XR

```
XR Plug-in Management:
  - Enable ARKit
  - ARKit XR Plugin Settings:
    - Enable ARKit: True
    - Depth: Enabled
    - Plane Detection: Horizontal and Vertical
```

#### الخطوة 4: معرّف الحزمة

```
Bundle Identifier: com.yourcompany.arsketchworld
```

---

## 🏗️ المرحلة الخامسة: البناء والنشر

### بناء APK (Android)

```bash
# في Unity
File > Build Settings
  - Select "Android"
  - Click "Build"
  - اختر مجلد الحفظ
  - انتظر انتهاء البناء (5-15 دقيقة)

# سيتم إنشاء ملف .apk
```

### تثبيت على جهاز Android

```bash
# عبر ADB
adb install -r path/to/app.apk

# أو عبر USB
# انسخ الملف إلى الجهاز وثبته يدوياً
```

### بناء لـ iOS

```bash
# في Unity
File > Build Settings
  - Select "iOS"
  - Click "Build"
  - اختر مجلد الحفظ

# سيتم إنشاء مشروع Xcode
```

### تثبيت على جهاز iOS

```bash
# فتح المشروع في Xcode
open -a Xcode path/to/Unity-iPhone.xcodeproj

# تسجيل الدخول بحسابك Apple
# اختر الجهاز المتصل
# انقر على Play للبناء والتشغيل
```

---

## 🧪 المرحلة السادسة: الاختبار

### الاختبار على المحاكي

#### Android Emulator

```bash
# فتح Android Studio
# Tools > Device Manager
# Create Virtual Device
# اختر Pixel 6 Pro
# اختر Android 13 (API 33)
# انقر على Play

# في Unity
File > Build Settings
  - Select "Android"
  - Check "Run Device" > "Emulator"
  - Click "Build and Run"
```

#### iOS Simulator

```bash
# فتح Xcode
# Xcode > Preferences > Locations
# اختر Xcode 14.0 أو أحدث

# في Unity
File > Build Settings
  - Select "iOS"
  - Click "Build"

# في Xcode
# اختر "iPhone 14" من Simulator
# انقر على Play
```

### الاختبار على جهاز حقيقي

#### Android

```bash
# تفعيل وضع المطور
Settings > About Phone > Build Number (اضغط 7 مرات)

# تفعيل USB Debugging
Settings > Developer Options > USB Debugging

# توصيل الجهاز بـ USB

# في Unity
adb devices  # تحقق من الاتصال
File > Build Settings > Build and Run
```

#### iOS

```bash
# توصيل الجهاز بـ USB

# في Xcode
# اختر الجهاز من القائمة العلوية
# انقر على Play
```

---

## 🔍 استكشاف الأخطاء

### خطأ: "AR Foundation not found"

```bash
# الحل:
# 1. Window > TextMesh Pro > Import TMP Essentials
# 2. Window > XR Plugin Management > Install AR Foundation
# 3. Restart Unity
```

### خطأ: "Android SDK not found"

```bash
# الحل:
# 1. Edit > Preferences > External Tools
# 2. اختر Android SDK Path يدوياً
# 3. أعد تشغيل Unity
```

### خطأ: "Xcode build failed"

```bash
# الحل:
# 1. تأكد من تثبيت Xcode الأخير
# 2. xcode-select --reset
# 3. أعد محاولة البناء
```

### خطأ: "Hugging Face API timeout"

```bash
# الحل:
# 1. تحقق من الاتصال بالإنترنت
# 2. تحقق من صحة المفتاح
# 3. زيادة timeout في AIIntegrationSystem.cs
```

---

## 📚 الخطوات التالية

### 1. تخصيص الأصول

```bash
# أضف نماذجك الخاصة
Assets/Models/
  - train.fbx
  - car.fbx
  - dinosaur.fbx
```

### 2. إضافة الأصوات

```bash
# أضف الأصوات
Assets/Audio/
  - train_sound.mp3
  - car_engine.mp3
  - dinosaur_roar.mp3
```

### 3. إضافة الرسوم المتحركة

```bash
# أنشئ رسوم متحركة
Assets/Animations/
  - train_move.anim
  - car_drive.anim
  - dinosaur_walk.anim
```

### 4. الاختبار على أجهزة متعددة

```bash
# اختبر على:
- Pixel 6 Pro (Android)
- iPhone 14 (iOS)
- Samsung Galaxy S23 (Android)
- iPad Air (iOS)
```

---

## 🎉 تم! الآن أنت جاهز

```bash
# شغّل اللعبة!
File > Play (في المحرر)
# أو
Build and Run (على الجهاز)
```

---

**ملاحظات مهمة:**
- احفظ مشروعك بانتظام
- استخدم Git للتحكم في الإصدارات
- اختبر على أجهزة حقيقية قبل النشر
- قراءة الوثائق الرسمية للمشاكل المعقدة

**آخر تحديث:** أبريل 2026
